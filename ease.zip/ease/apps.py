from django.apps import AppConfig


class EaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ease'
