from django.contrib import admin
from .models import Faculty,Engineering_Course,Dentistry_Course,Architecture_and_Fine_Arts_Course,Educational_Sciences_Course,Arts_and_Sciences_Course,Law_Course,Economics_and_Administrative_Sciences_Course,Health_Sciences_Course,Phamarcy_Course

admin.site.register(Faculty)
admin.site.register(Engineering_Course)
admin.site.register(Dentistry_Course)
admin.site.register(Architecture_and_Fine_Arts_Course)
admin.site.register(Educational_Sciences_Course)
admin.site.register(Arts_and_Sciences_Course)
admin.site.register(Law_Course)
admin.site.register(Economics_and_Administrative_Sciences_Course)
admin.site.register(Health_Sciences_Course)
admin.site.register(Phamarcy_Course)


